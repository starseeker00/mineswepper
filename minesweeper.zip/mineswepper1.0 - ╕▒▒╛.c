#include <conio.h>
#include <math.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define random(x) (rand() % x)

const int up = 11;
const int left = 12;
const int down = 13;
const int right = 14;
const int enter = 15;
const int click = 16;
const int setmine = 17;
const int checkmine = 18;
const int othertype = 19;
const int esc = 20;
const int meanless = -1;

const char click_button = 'q';
const char setmine_button = 'w';
const char checkmine_button = 'e';

int X = 30;       //���̳�
int Y = 16;       //���̿�
char b[100][100]; //��������
char c[100][100]; //ʵ������
int s;            //������
int t;            //��ǰ������

int type_in_button = -1;
int game_run_situation = 1;    //��Ϸ�Ƿ��������
int get_type_in_situation = 1; //�����жϳ�������״̬
int timer = 0;
double game_run_timer_base = 0;

//是否为有效落子点
int is_on_board(int i, int j)
{
    if ((i >= 1) && (i <= X) && (j >= 1) && (j <= Y)) {
        return 1;
    }
    else {
        return 0;
    }
}

//清空棋盘
void new_board()
{
    int i, j;
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            b[i][j] = ' ';
            c[i][j] = ' ';
        }
    }
}

//地雷棋盘
void bomb_board(int num_of_mine)
{
    //埋雷
    int i, j;
    srand((int)time(0));
    t = num_of_mine;
    s = num_of_mine;
    int s2 = s;
    while (s2 > 0) {
        i = random(X);
        j = random(Y);
        if (c[i][j] == ' ') {
            c[i][j] = '*';
            s2 -= 1;
        }
    }

    //数字
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            if (c[i][j] == ' ') {
                char k = '0';
                int xd, yd;
                for (xd = -1; xd <= 1; xd++) {
                    for (yd = -1; yd <= 1; yd++) {
                        if ((xd == 0) && (yd == 0)) {
                            continue;
                        }
                        if (is_on_board(i + xd + 1, j + yd + 1)) {
                            if (c[i + xd][j + yd] == '*') {
                                k += 1;
                            }
                        }
                    }
                }
                c[i][j] = k;
            }
        }
    }
}

//����
int discover(int i, int j)
{
    if (b[i][j] != ' ') { //不要重复点击
        return 1;
    }

    b[i][j] = c[i][j]; //显示

    if (b[i][j] == '*') { //触雷，结�??
        return 0;
    }

    if (b[i][j] == '0') { //点开一�??
        int xd, yd;
        for (xd = -1; xd <= 1; xd++) {
            for (yd = -1; yd <= 1; yd++) {
                if ((xd == 0) && (yd == 0)) {
                    continue;
                }
                if (is_on_board(i + xd + 1, j + yd + 1)) {
                    if (b[i + xd][j + yd] != ' ') {
                        continue;
                    }
                    discover(i + xd, j + yd);
                }
            }
        }
        return 2;
    }
}

//���;0�����ף�1����Ч������2���Ѳ���
int make_move(int i, int j, char tile)
{
    //����ֵΪ0�����ף�
    //����ֵΪ1����Ч������
    //����ֵΪ2���Ѳ���

    //��ͨ���
    if (tile == 'l') {
        return discover(i, j);
    }

    //��ͨ�Ҽ�
    if (tile == 'r') {
        if (b[i][j] == ' ') {
            b[i][j] = '#';
            t -= 1;
            return 2;
        }
        else if (b[i][j] == '#') {
            b[i][j] = ' ';
            t += 1;
            return 2;
        }
        else {
            return 1;
        }
    }

    //˫������
    if (tile == 'd') {
        if ((b[i][j] == '0') || (b[i][j] == ' ') || (b[i][j] == '#')) {
            return 1;
        }
        else { //��������֣������ж�
            char k = '0';
            int xd, yd;
            for (xd = -1; xd <= 1; xd++) {
                for (yd = -1; yd <= 1; yd++) {
                    if ((xd == 0) && (yd == 0)) {
                        continue;
                    }
                    if (is_on_board(i + xd + 1, j + yd + 1)) {
                        if (b[i + xd][j + yd] == '#') {
                            k += 1;
                        }
                    }
                }
            }
            if (b[i][j] != k) { //�����Ƿ���ڱ����
                return 1;
            }
            else { //�������Ҫ���򷭿���Χ
                int xd, yd;
                int p, flag = 2;
                for (xd = -1; xd <= 1; xd++) {
                    for (yd = -1; yd <= 1; yd++) {
                        if ((xd == 0) && (yd == 0)) {
                            continue;
                        }
                        if (is_on_board(i + xd + 1, j + yd + 1)) {
                            if (b[i + xd][j + yd] == ' ') {
                                p = discover(i + xd, j + yd);
                                if (p == 0) {
                                    flag = 0;
                                }
                            }
                        }
                    }
                }
                return flag;
            }
        }
    }
}

//是否胜利
int is_won()
{
    int i, j;
    int k = 0;
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            if ((b[i][j] >= '0') && (b[i][j] <= '8')) {
                k += 1;
            }
        }
    }
    if (k == X * Y - s) {
        return 1;
    }
    else {
        return 0;
    }
}

void gotoxy(int x, int y)
{
    short a = (short)x;
    short b = (short)y;
    COORD pos = {a, b};
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE); // 获取标准输出设备句柄
    SetConsoleCursorPosition(hOut, pos);           //两个参数分别是指定哪个窗体，具体位置
}

void get_type_in(void *arg)
{
    char c1, c2;
    while (get_type_in_situation) {
        c1 = getch();
        if ((c1 == 0) || (c1 == -32)) {
            c2 = getch();
            if (c2 == 72) {
                type_in_button = up;
            }
            else if (c2 == 75) {
                type_in_button = left;
            }
            else if (c2 == 80) {
                type_in_button = down;
            }
            else if (c2 == 77) {
                type_in_button = right;
            }
        }
        else if (c1 == 13) {
            type_in_button = enter;
        }
        else if (c1 == click_button) {
            type_in_button = click;
        }
        else if (c1 == setmine_button) {
            type_in_button = setmine;
        }
        else if (c1 == checkmine_button) {
            type_in_button = checkmine;
        }
        else if (c1 == 27) {
            type_in_button = esc;
        }
        else {
            type_in_button = othertype;
        }
    }
    _endthread();
}

//0 normal;1 error
int start_print_out()
{
    int start_print_situation = 1;
    int i = 0, type_in = 1;
    system("cls");
    type_in_button = meanless;
    while (start_print_situation) {
        if (type_in_button == left) {
            type_in_button = meanless;
            i--;
            type_in = 1;
        }
        else if (type_in_button == right) {
            type_in_button = meanless;
            i++;
            type_in = 1;
        }
        else if (type_in_button == enter) {
            type_in_button = meanless;
            start_print_situation = 0;
        }
        if (type_in) {
            type_in = 0;
            char s[500] = "ɨ��1.0\n��ѡ����Ϸģʽ,ʹ�÷����ѡ���Լ��س�ȷ��\n�� ��ͨ ���� �Զ���\n";
            i = i + 4;
            i = i % 4;
            if (i == 0) {
                strcat(s, "====                 ");
            }
            else if (i == 1) {
                strcat(s, "     ====            ");
            }
            else if (i == 2) {
                strcat(s, "          ====       ");
            }
            else if (i == 3) {
                strcat(s, "               ======");
            }
            gotoxy(0, 0);
            printf("\n%s\n", s);
        }
        Sleep(70);
    }
    //ѡ����Ϸ�Ѷ�
    if (i == 0) {
        X = 9;
        Y = 9;
        t = 10;
        return 0;
    }
    else if (i == 1) {
        X = 16;
        Y = 16;
        t = 40;
        return 0;
    }
    else if (i == 2) {
        X = 30;
        Y = 16;
        t = 99;
        return 0;
    }
    else if (i == 3) {
        //return 1;
        system("cls");
        get_type_in_situation = 0;
        type_in_button = meanless;
        printf("�����������\n");
        while (type_in_button == meanless) {
        }
        printf("�������̿���(9-30):\n");
        if (scanf("%d", &Y) == 0 || Y < 9 || Y > 30) {
            setbuf(stdin, NULL);
            return 1;
        }
        printf("�������̸߶�(9-24):\n");
        if (scanf("%d", &X) == 0 || X < 9 || X > 24) {
            setbuf(stdin, NULL);
            return 1;
        }
        printf("���������(10-668):\n");
        if (scanf("%d", &t) == 0 || t < 10 || t > X * Y || t > 668) {
            setbuf(stdin, NULL);
            return 1;
        }
        system("cls");
    }
    return 0;
}

void gameover()
{
    int i, j;
    for (i = 0; i < X; i++) {
        for (j = 0; j < Y; j++) {
            if (c[i][j] == '*') {
                b[i][j] = c[i][j];
            }
        }
    }
}

//˫����˸,���������̶�Ӧλ���û�Ϊ��˸�ַ�,����x,yΪ��Ҫ��˸������������,change=1�ı�,change=0��ԭ
void double_click_change(int x, int y, int change)
{
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) {
                continue;
            }
            if (b[x + i][y + j] == ' ' && change == 1) {
                b[x + i][y + j] = '%';
            }
            else if (b[x + i][y + j] == '%' && change == 0) {
                b[x + i][y + j] = ' ';
            }
        }
    }
}

//1 means win;0 means loose;2 means exit;
int game_run(char game_board[100][100], int max_x, int max_y)
{
    int x = max_x / 2, y = max_y / 2, typein = 1, dark = 0;
    int double_click_mark = 0;                                  //˫�����,����0��������˫����˸
    int exit_game = 0;                                          //����Ƿ�ʹ��exit�˳���Ϸ
    double time_per_flash = (double)(clock() / CLOCKS_PER_SEC); //����ˢ�¼�ʱ
    system("cls");
    while (game_run_situation) {
        if (type_in_button == meanless || double_click_mark > 0) {
        }
        else if (type_in_button == up) {
            type_in_button = meanless;
            x--;
            if (x < 0) {
                x = 0;
            }
            typein = 1;
        }
        else if (type_in_button == down) {
            type_in_button = meanless;
            x++;
            if (x > max_x - 1) {
                x = max_x - 1;
            }
            typein = 1;
        }
        else if (type_in_button == left) {
            type_in_button = meanless;
            y--;
            if (y < 0) {
                y = 0;
            }
            typein = 1;
        }
        else if (type_in_button == right) {
            type_in_button = meanless;
            y++;
            if (y > max_y - 1) {
                y = max_y - 1;
            }
            typein = 1;
        }
        else if (type_in_button == esc) {
            game_run_situation = 0;
            exit_game = 1;
        }
        else if (type_in_button == click) {
            type_in_button = meanless;
            if (make_move(x, y, 'l') == 0) {
                gameover();
                game_run_situation = 0;
            }
            typein = 1;
        }
        else if (type_in_button == setmine) {
            type_in_button = meanless;
            make_move(x, y, 'r');
            typein = 1;
        }
        else if (type_in_button == checkmine) {
            type_in_button = meanless;
            int re = make_move(x, y, 'd'); //����make_move����ֵ
            if (re == 0) {
                gameover();
                game_run_situation = 0;
            }
            else if (re == 1) {
                double_click_change(x, y, 1);
                double_click_mark = 2;
            }
            typein = 1;
        }
        //��ӡ����

        int time_flow = (double)(clock() / CLOCKS_PER_SEC) - time_per_flash;
        if ((time_flow > 0.5) || (typein == 1) || (double_click_mark > 0)) {
            dark = !dark;
            if (typein) {
                typein = 0;
                dark = 1;
            }
            char s[500 * 500] = "";
            strcat(s, "  ");
            for (int j = 0; j < max_y * 2; j++) {
                strcat(s, "_");
            }
            strcat(s, "\n");
            for (int i = 0; i < max_x; i++) {
                strcat(s, " |");
                for (int j = 0; j < max_y; j++) {
                    if ((i == x) && (j == y) && dark) {
                        strcat(s, "@ ");
                    }
                    else if (game_board[i][j] == '0') {
                        strcat(s, "  ");
                    }
                    else if (game_board[i][j] == ' ') {
                        strcat(s, "��");
                    }
                    else if (game_board[i][j] == '%') {
                        strcat(s, "  ");
                    }
                    else {
                        int temp = strlen(s);
                        s[temp] = game_board[i][j];
                        s[temp + 1] = ' ';
                        s[temp + 2] = '\0';
                    }
                }
                strcat(s, "|\n");
            }
            strcat(s, "  ");
            for (int j = 0; j < max_y * 2; j++) {
                strcat(s, "_");
            }
            if (double_click_mark > 0) {
                double_click_mark--;
                Sleep(20);
                if (double_click_mark == 1) {
                    double_click_change(x, y, 0);
                }
            }
            strcat(s, "\n");
            gotoxy(0, 0);
            printf("\nΪ�������õ���Ϸ����,�뽫���ڵ������ʴ�С");
            printf("\n%s%c=�����%c=�Ҽ���%c=˫��,esc=�������˵�\nʣ�������:%d     \n", s, click_button, setmine_button, checkmine_button, t);
            printf("��ʱ:%.0fs\n", (double)(clock() - game_run_timer_base) / CLOCKS_PER_SEC);
            time_per_flash = (double)(clock() / CLOCKS_PER_SEC);
        }
        if (is_won()) {
            game_run_situation = 0;
            return 1;
        }
    }
    if (exit_game) {
        return 2;
    }
    else {
        return 0;
    };
}

int main()
{
    get_type_in_situation = 1;
    _beginthread(get_type_in, 0, NULL); //
    int continue_program = 1;
    while (continue_program) {
        if (get_type_in_situation == 0) {
            get_type_in_situation = 1;
            _beginthread(get_type_in, 0, NULL);
        }

        while (start_print_out()) {
            if (get_type_in_situation == 0) {
                get_type_in_situation = 1;
                _beginthread(get_type_in, 0, NULL);
            }
            type_in_button = meanless;
            printf("����������");
            while (type_in_button == meanless)
                ;
        }

        if (get_type_in_situation == 0) {
            get_type_in_situation = 1;
            _beginthread(get_type_in, 0, NULL);
        }
        game_run_situation = 1;
        new_board();
        bomb_board(t);
        game_run_timer_base = clock();
        int re_of_game_run = game_run(b, X, Y); //����game_run���
        if (re_of_game_run == 1) {
            printf("**win**\n");
        }
        else if (re_of_game_run == 0) {
            printf("**looooose**\n");
        }
        else if (re_of_game_run == 2) {
            continue;
        }
        get_type_in_situation = 0;
        type_in_button = meanless;
        printf("�����������\n");
        while (type_in_button == meanless)
            ;
        printf("�Ƿ������Ϸy/n\n");
        char yes_or_no;
        while ((scanf("%c", &yes_or_no) == 0) || (yes_or_no != 'y' && yes_or_no != 'n')) {
        }
        if (yes_or_no == 'n') {
            continue_program = 0;
        }
    }
    get_type_in_situation = 0;
    return 0;
}
